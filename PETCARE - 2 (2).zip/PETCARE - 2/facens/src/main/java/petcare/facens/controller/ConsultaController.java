package petcare.facens.controller;

import petcare.facens.entity.Consulta;
import petcare.facens.service.ConsultaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/consultas")
public class ConsultaController {
    
    @Autowired
    private ConsultaService consultaService;
    
    /**
     * POST /api/consultas
     * CRÍTICO: Valida conflito de agenda e especialidade
     */
    @PostMapping
    public ResponseEntity<?> agendarConsulta(@RequestBody Consulta consulta) {
        try {
            Consulta consultaAgendada = consultaService.agendarConsulta(consulta);
            return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(consultaAgendada);
        } catch (RuntimeException e) {
            return ResponseEntity
                .badRequest()
                .body(Map.of("erro", e.getMessage()));
        }
    }
    
    /**
     * GET /api/consultas/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<Consulta> obterPorId(@PathVariable Long id) {
        return consultaService.obterPorId(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }
    
    /**
     * GET /api/consultas
     */
    @GetMapping
    public ResponseEntity<List<Consulta>> listarTodas() {
        return ResponseEntity.ok(consultaService.listarTodas());
    }
    
    /**
     * GET /api/consultas/veterinario/{vetId}
     */
    @GetMapping("/veterinario/{vetId}")
    public ResponseEntity<List<Consulta>> listarAgendadasPorVeterinario(
        @PathVariable Long vetId) {
        return ResponseEntity.ok(
            consultaService.listarConsultasAgendadasPorVeterinario(vetId)
        );
    }
    
    /**
     * GET /api/consultas/animal/{animalId}/historico
     * CRÍTICO: Registro de histórico
     */
    @GetMapping("/animal/{animalId}/historico")
    public ResponseEntity<List<Consulta>> historicoConsultasPorAnimal(
        @PathVariable Long animalId) {
        return ResponseEntity.ok(
            consultaService.listarHistoricoConsultasPorAnimal(animalId)
        );
    }
    
    /**
     * PUT /api/consultas/{id}/finalizar
     * Finaliza consulta e atualiza prontuário
     */
    @PutMapping("/{id}/finalizar")
    public ResponseEntity<?> finalizarConsulta(
        @PathVariable Long id,
        @RequestBody Map<String, String> dados) {
        try {
            String diagnostico = dados.get("diagnostico");
            String tratamento = dados.get("tratamento");
            
            Consulta consultaFinalizada = consultaService.finalizarConsulta(
                id, diagnostico, tratamento
            );
            return ResponseEntity.ok(consultaFinalizada);
        } catch (RuntimeException e) {
            return ResponseEntity
                .badRequest()
                .body(Map.of("erro", e.getMessage()));
        }
    }
    
    /**
     * PUT /api/consultas/{id}/cancelar
     */
    @PutMapping("/{id}/cancelar")
    public ResponseEntity<?> cancelarConsulta(@PathVariable Long id) {
        try {
            consultaService.cancelarConsulta(id);
            return ResponseEntity.ok(Map.of("mensagem", "Consulta cancelada"));
        } catch (RuntimeException e) {
            return ResponseEntity
                .badRequest()
                .body(Map.of("erro", e.getMessage()));
        }
    }
}
