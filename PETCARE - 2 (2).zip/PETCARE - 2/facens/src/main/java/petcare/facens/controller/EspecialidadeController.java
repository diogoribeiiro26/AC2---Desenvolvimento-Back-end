package petcare.facens.controller;


import petcare.facens.entity.Especialidade;
import petcare.facens.service.EspecialidadeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/especialidades")
public class EspecialidadeController {
    
    @Autowired
    private EspecialidadeService especialidadeService;
    
    @PostMapping
    public ResponseEntity<Especialidade> criar(@RequestBody Especialidade especialidade) {
        return ResponseEntity
            .status(HttpStatus.CREATED)
            .body(especialidadeService.criar(especialidade));
    }
    
    @GetMapping
    public ResponseEntity<List<Especialidade>> listarTodas() {
        return ResponseEntity.ok(especialidadeService.listarTodas());
    }
}