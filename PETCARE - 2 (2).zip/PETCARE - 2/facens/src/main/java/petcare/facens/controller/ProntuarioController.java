package petcare.facens.controller;

import petcare.facens.entity.Prontuario;
import petcare.facens.entity.Vacinacao;
import petcare.facens.service.ProntuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/prontuarios")
public class ProntuarioController {
    
    @Autowired
    private ProntuarioService prontuarioService;
    
    @PostMapping("/animal/{animalId}")
    public ResponseEntity<Prontuario> criarProntuario(@PathVariable Long animalId) {
        return ResponseEntity
            .status(HttpStatus.CREATED)
            .body(prontuarioService.criarProntuario(animalId));
    }
    
    @GetMapping("/animal/{animalId}")
    public ResponseEntity<Prontuario> obterPorAnimalId(@PathVariable Long animalId) {
        return prontuarioService.obterPorAnimalId(animalId)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }
    
    @PostMapping("/{animalId}/vacinacoes")
    public ResponseEntity<Prontuario> adicionarVacinacao(
        @PathVariable Long animalId,
        @RequestBody Vacinacao vacinacao) {
        return ResponseEntity.ok(
            prontuarioService.adicionarVacinacao(animalId, vacinacao)
        );
    }
}