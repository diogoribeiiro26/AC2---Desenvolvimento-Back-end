package petcare.facens.controller;

import petcare.facens.entity.Tutor;
import petcare.facens.service.TutorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/tutores")
public class TutorController {
    
    @Autowired
    private TutorService tutorService;
    
    @PostMapping
    public ResponseEntity<Tutor> criarTutor(@RequestBody Tutor tutor) {
        return ResponseEntity
            .status(HttpStatus.CREATED)
            .body(tutorService.criarTutor(tutor));
    }
    
    @GetMapping
    public ResponseEntity<List<Tutor>> listarTodos() {
        return ResponseEntity.ok(tutorService.listarTodos());
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Tutor> obterPorId(@PathVariable Long id) {
        return tutorService.obterPorId(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Tutor> atualizar(
        @PathVariable Long id,
        @RequestBody Tutor tutor) {
        try {
            return ResponseEntity.ok(tutorService.atualizarTutor(id, tutor));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        tutorService.deletarTutor(id);
        return ResponseEntity.noContent().build();
    }
}