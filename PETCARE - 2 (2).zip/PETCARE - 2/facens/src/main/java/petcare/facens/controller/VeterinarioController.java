package petcare.facens.controller;

import petcare.facens.entity.Veterinario;
import petcare.facens.service.VeterinarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/veterinarios")
public class VeterinarioController {
    
    @Autowired
    private VeterinarioService veterinarioService;
    
    @PostMapping
    public ResponseEntity<Veterinario> criar(@RequestBody Veterinario veterinario) {
        return ResponseEntity
            .status(HttpStatus.CREATED)
            .body(veterinarioService.criar(veterinario));
    }
    
    @GetMapping
    public ResponseEntity<List<Veterinario>> listarTodos() {
        return ResponseEntity.ok(veterinarioService.listarTodos());
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Veterinario> obterPorId(@PathVariable Long id) {
        return veterinarioService.obterPorId(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }
    
    @GetMapping("/especialidade/{especialidadeId}")
    public ResponseEntity<List<Veterinario>> listarPorEspecialidade(
        @PathVariable Long especialidadeId) {
        return ResponseEntity.ok(
            veterinarioService.listarPorEspecialidade(especialidadeId)
        );
    }
}
