package petcare.facens.entity;

import lombok.*;
import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "prontuarios")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Prontuario {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    // Relacionamento 1:1 com Animal
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "animal_id", nullable = false, unique = true)
    private Animal animal;
    
    @Column(columnDefinition = "TEXT")
    private String historico;
    
    private String condicoesSaude;
    
    private LocalDate ultimaAtualizacao;
    
    // Relacionamento 1:N com Vacinação
    @OneToMany(mappedBy = "prontuario", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Vacinacao> vacinacoes;
    
    // Relacionamento 1:1 com Consulta (última consulta registrada)
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "consulta_id")
    private Consulta consulta;
}