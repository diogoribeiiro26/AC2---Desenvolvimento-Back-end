package petcare.facens.entity;

public enum StatusConsulta {
    AGENDADA,
    REALIZADA,
    CANCELADA
}