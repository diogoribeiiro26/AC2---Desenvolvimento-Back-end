package petcare.facens.entity;


import lombok.*;
import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "vacinacoes")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Vacinacao {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String nomeVacina;
    
    @Column(nullable = false)
    private LocalDate dataVacinacao;
    
    private LocalDate proximaDose;
    
    private String veterinarioResponsavel;
    
    // Relacionamento N:1 com Prontuário
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "prontuario_id", nullable = false)
    private Prontuario prontuario;
}
