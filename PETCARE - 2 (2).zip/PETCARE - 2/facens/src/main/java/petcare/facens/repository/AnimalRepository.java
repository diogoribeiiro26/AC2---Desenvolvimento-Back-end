package petcare.facens.repository;

import petcare.facens.entity.Animal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface AnimalRepository extends JpaRepository<Animal, Long> {
    
    List<Animal> findByTutorId(Long tutorId);
    
    @Query("SELECT a FROM Animal a WHERE a.tutor.id = :tutorId")
    List<Animal> buscarAnimaisPorTutor(@Param("tutorId") Long tutorId);
}
