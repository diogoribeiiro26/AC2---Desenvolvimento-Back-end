package petcare.facens.repository;

import petcare.facens.entity.Consulta;
import petcare.facens.entity.StatusConsulta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ConsultaRepository extends JpaRepository<Consulta, Long> {
    
    // Verificar conflito de agenda
    @Query("SELECT c FROM Consulta c WHERE c.veterinario.id = :vetId " +
           "AND c.dataHora = :dataHora")
    List<Consulta> buscarConsultasConflitantesPorVeterinario(
        @Param("vetId") Long vetId, 
        @Param("dataHora") String dataHora);
    
    // Consultas agendadas por veterinário
    @Query("SELECT c FROM Consulta c WHERE c.veterinario.id = :vetId " +
           "AND c.status = 'AGENDADA' ORDER BY c.dataHora ASC")
    List<Consulta> buscarConsultasAgendadasPorVeterinario(@Param("vetId") Long vetId);
    
    // Histórico de consultas por animal
    @Query("SELECT c FROM Consulta c WHERE c.animal.id = :animalId " +
           "ORDER BY c.dataHora DESC")
    List<Consulta> buscarHistoricoConsultasPorAnimal(@Param("animalId") Long animalId);
}