package petcare.facens.repository;

import petcare.facens.entity.Veterinario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface VeterinarioRepository extends JpaRepository<Veterinario, Long> {
    
    Veterinario findByCrmv(String crmv);
    
    @Query("SELECT v FROM Veterinario v WHERE v.especialidade.id = :especialidadeId")
    List<Veterinario> buscarVeterinariosPorEspecialidade(@Param("especialidadeId") Long especialidadeId);
}
