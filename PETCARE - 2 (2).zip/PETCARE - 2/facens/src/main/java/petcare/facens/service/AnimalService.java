package petcare.facens.service;

import petcare.facens.entity.Animal;
import petcare.facens.entity.Tutor;
import petcare.facens.repository.AnimalRepository;
import petcare.facens.repository.TutorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class AnimalService {
    
    @Autowired
    private AnimalRepository animalRepository;
    
    @Autowired
    private TutorRepository tutorRepository;
    
    public Animal criarAnimal(Animal animal) {
        // Validar se tutor existe
        if (animal.getTutor() == null || animal.getTutor().getId() == null) {
            throw new RuntimeException("ID do tutor é obrigatório");
        }
        
        Optional<Tutor> tutorOpt = tutorRepository.findById(animal.getTutor().getId());
        if (!tutorOpt.isPresent()) {
            throw new RuntimeException("Tutor não encontrado");
        }
        
        animal.setTutor(tutorOpt.get());
        return animalRepository.save(animal);
    }
    
    public Optional<Animal> obterPorId(Long id) {
        return animalRepository.findById(id);
    }
    
    public List<Animal> listarPorTutor(Long tutorId) {
        return animalRepository.findByTutorId(tutorId);
    }
    
    public List<Animal> listarTodos() {
        return animalRepository.findAll();
    }
    
    public Animal atualizarAnimal(Long id, Animal animalAtualizado) {
        Optional<Animal> animalOpt = animalRepository.findById(id);
        
        if (!animalOpt.isPresent()) {
            throw new RuntimeException("Animal não encontrado");
        }
        
        Animal animal = animalOpt.get();
        animal.setNome(animalAtualizado.getNome());
        animal.setEspecie(animalAtualizado.getEspecie());
        animal.setRaca(animalAtualizado.getRaca());
        animal.setPeso(animalAtualizado.getPeso());
        animal.setDataNascimento(animalAtualizado.getDataNascimento());
        
        return animalRepository.save(animal);
    }
    
    public void deletarAnimal(Long id) {
        animalRepository.deleteById(id);
    }
}