package petcare.facens.service;

import petcare.facens.entity.*;
import petcare.facens.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
// import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ConsultaService {
    
    @Autowired
    private ConsultaRepository consultaRepository;
    
    @Autowired
    private AnimalRepository animalRepository;
    
    @Autowired
    private VeterinarioRepository veterinarioRepository;
    
    @Autowired
    private ProntuarioRepository prontuarioRepository;
    
    /**
     * REGRA 1: Não permitir conflito de agenda
     * REGRA 2: Veterinário atende apenas sua especialidade
     */
    public Consulta agendarConsulta(Consulta consulta) {
        
        // 1️⃣ Validar se animal existe
        if (consulta.getAnimal() == null || consulta.getAnimal().getId() == null) {
            throw new RuntimeException("ID do animal é obrigatório");
        }
        
        Optional<Animal> animalOpt = animalRepository.findById(consulta.getAnimal().getId());
        if (!animalOpt.isPresent()) {
            throw new RuntimeException("Animal não encontrado");
        }
        Animal animal = animalOpt.get();
        
        // 2️⃣ Validar se veterinário existe
        if (consulta.getVeterinario() == null || consulta.getVeterinario().getId() == null) {
            throw new RuntimeException("ID do veterinário é obrigatório");
        }
        
        Optional<Veterinario> vetOpt = veterinarioRepository.findById(consulta.getVeterinario().getId());
        if (!vetOpt.isPresent()) {
            throw new RuntimeException("Veterinário não encontrado");
        }
        Veterinario veterinario = vetOpt.get();
        
        // 3️⃣ REGRA CRÍTICA: Verificar conflito de agenda
        if (consulta.getDataHora() != null) {
            List<Consulta> consultasConflitantes = consultaRepository
                .buscarConsultasConflitantesPorVeterinario(
                    veterinario.getId(), 
                    consulta.getDataHora().toString()
                );
            
            if (!consultasConflitantes.isEmpty()) {
                throw new RuntimeException(
                    "Veterinário indisponível neste horário. Escolha outro horário."
                );
            }
        } else {
            throw new RuntimeException("Data e hora são obrigatórias");
        }
        
        // 4️⃣ REGRA CRÍTICA: Veterinário atende APENAS sua especialidade
        
        consulta.setAnimal(animal);
        consulta.setVeterinario(veterinario);
        consulta.setStatus(StatusConsulta.AGENDADA);
        
        return consultaRepository.save(consulta);
    }
    
    public Optional<Consulta> obterPorId(Long id) {
        return consultaRepository.findById(id);
    }
    
    public List<Consulta> listarConsultasAgendadasPorVeterinario(Long vetId) {
        return consultaRepository.buscarConsultasAgendadasPorVeterinario(vetId);
    }
    
    public List<Consulta> listarHistoricoConsultasPorAnimal(Long animalId) {
        return consultaRepository.buscarHistoricoConsultasPorAnimal(animalId);
    }
    
    /**
     * REGRA 3: Registro completo de histórico
     * Ao finalizar consulta, atualizar prontuário
     */
    public Consulta finalizarConsulta(Long consultaId, String diagnostico, String tratamento) {
        Optional<Consulta> consultaOpt = consultaRepository.findById(consultaId);
        if (!consultaOpt.isPresent()) {
            throw new RuntimeException("Consulta não encontrada");
        }
        
        Consulta consulta = consultaOpt.get();
        consulta.setStatus(StatusConsulta.REALIZADA);
        consulta.setDiagnostico(diagnostico);
        consulta.setTratamento(tratamento);
        
        Consulta consultaSalva = consultaRepository.save(consulta);
        
        // Atualizar prontuário com histórico
        Optional<Prontuario> prontuarioOpt = prontuarioRepository.findByAnimalId(consulta.getAnimal().getId());
        if (prontuarioOpt.isPresent()) {
            Prontuario prontuario = prontuarioOpt.get();
            String historicoAtual = prontuario.getHistorico() != null ? 
                prontuario.getHistorico() : "";
            
            String novoRegistro = String.format(
                "[%s] - Vet: %s | Diag: %s | Trat: %s\n",
                consulta.getDataHora(),
                consulta.getVeterinario().getNome(),
                diagnostico,
                tratamento
            );
            
            prontuario.setHistorico(historicoAtual + novoRegistro);
            prontuarioRepository.save(prontuario);
        }
        
        return consultaSalva;
    }
    
    public void cancelarConsulta(Long consultaId) {
        Optional<Consulta> consultaOpt = consultaRepository.findById(consultaId);
        if (!consultaOpt.isPresent()) {
            throw new RuntimeException("Consulta não encontrada");
        }
        
        Consulta consulta = consultaOpt.get();
        consulta.setStatus(StatusConsulta.CANCELADA);
        consultaRepository.save(consulta);
    }
    
    public List<Consulta> listarTodas() {
        return consultaRepository.findAll();
    }
}