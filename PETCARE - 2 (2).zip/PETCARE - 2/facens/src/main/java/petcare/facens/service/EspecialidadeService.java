package petcare.facens.service;


import petcare.facens.entity.Especialidade;
import petcare.facens.repository.EspecialidadeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class EspecialidadeService {
    
    @Autowired
    private EspecialidadeRepository especialidadeRepository;
    
    public Especialidade criar(Especialidade especialidade) {
        if (especialidadeRepository.findByNome(especialidade.getNome()) != null) {
            throw new RuntimeException("Especialidade já existe");
        }
        return especialidadeRepository.save(especialidade);
    }
    
    public List<Especialidade> listarTodas() {
        return especialidadeRepository.findAll();
    }
}
