package petcare.facens.service;

import petcare.facens.entity.*;
import petcare.facens.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.Optional;

@Service
public class ProntuarioService {
    
    @Autowired
    private ProntuarioRepository prontuarioRepository;
    
    @Autowired
    private AnimalRepository animalRepository;
    
    public Prontuario criarProntuario(Long animalId) {
        Optional<Animal> animalOpt = animalRepository.findById(animalId);
        if (!animalOpt.isPresent()) {
            throw new RuntimeException("Animal não encontrado");
        }
        
        Animal animal = animalOpt.get();
        Prontuario prontuario = Prontuario.builder()
            .animal(animal)
            .ultimaAtualizacao(LocalDate.now())
            .build();
        
        return prontuarioRepository.save(prontuario);
    }
    
    public Optional<Prontuario> obterPorAnimalId(Long animalId) {
        return prontuarioRepository.findByAnimalId(animalId);
    }
    
    public Prontuario adicionarVacinacao(Long animalId, Vacinacao vacinacao) {
        Optional<Prontuario> prontuarioOpt = prontuarioRepository.findByAnimalId(animalId);
        if (!prontuarioOpt.isPresent()) {
            throw new RuntimeException("Prontuário não encontrado");
        }
        
        Prontuario prontuario = prontuarioOpt.get();
        vacinacao.setProntuario(prontuario);
        
        if (prontuario.getVacinacoes() == null) {
            prontuario.setVacinacoes(new java.util.ArrayList<>());
        }
        
        prontuario.getVacinacoes().add(vacinacao);
        
        return prontuarioRepository.save(prontuario);
    }
}