package petcare.facens.service;


import petcare.facens.entity.Tutor;
import petcare.facens.repository.TutorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class TutorService {
    
    @Autowired
    private TutorRepository tutorRepository;
    
    public Tutor criarTutor(Tutor tutor) {
        if (tutorRepository.findByCpf(tutor.getCpf()) != null) {
            throw new RuntimeException("CPF já cadastrado");
        }
        if (tutorRepository.findByEmail(tutor.getEmail()) != null) {
            throw new RuntimeException("Email já cadastrado");
        }
        return tutorRepository.save(tutor);
    }
    
    public Optional<Tutor> obterPorId(Long id) {
        return tutorRepository.findById(id);
    }
    
    public List<Tutor> listarTodos() {
        return tutorRepository.findAll();
    }
    
    public Tutor atualizarTutor(Long id, Tutor tutorAtualizado) {
        return tutorRepository.findById(id).map(tutor -> {
            tutor.setNome(tutorAtualizado.getNome());
            tutor.setEmail(tutorAtualizado.getEmail());
            tutor.setTelefone(tutorAtualizado.getTelefone());
            tutor.setEndereco(tutorAtualizado.getEndereco());
            return tutorRepository.save(tutor);
        }).orElseThrow(() -> new RuntimeException("Tutor não encontrado"));
    }
    
    public void deletarTutor(Long id) {
        tutorRepository.deleteById(id);
    }
}
