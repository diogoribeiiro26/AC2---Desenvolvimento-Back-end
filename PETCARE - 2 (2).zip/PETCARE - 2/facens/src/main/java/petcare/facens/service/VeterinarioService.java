package petcare.facens.service;


import petcare.facens.entity.Especialidade;
import petcare.facens.entity.Veterinario;
import petcare.facens.repository.EspecialidadeRepository;
import petcare.facens.repository.VeterinarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class VeterinarioService {
    
    @Autowired
    private VeterinarioRepository veterinarioRepository;
    
    @Autowired
    private EspecialidadeRepository especialidadeRepository;
    
    public Veterinario criar(Veterinario veterinario) {
        if (veterinarioRepository.findByCrmv(veterinario.getCrmv()) != null) {
            throw new RuntimeException("CRMV já cadastrado");
        }
        return veterinarioRepository.save(veterinario);
    }
    
    public Optional<Veterinario> obterPorId(Long id) {
        return veterinarioRepository.findById(id);
    }
    
    public List<Veterinario> listarTodos() {
        return veterinarioRepository.findAll();
    }
    
    public List<Veterinario> listarPorEspecialidade(Long especialidadeId) {
        return veterinarioRepository.buscarVeterinariosPorEspecialidade(especialidadeId);
    }
}